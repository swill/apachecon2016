# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


"""Disables out-of-band management for a cluster"""
from baseCmd import *
from baseResponse import *
class disableOutOfBandManagementForClusterCmd (baseCmd):
    typeInfo = {}
    def __init__(self):
        self.isAsync = "true"
        """the ID of the cluster"""
        """Required"""
        self.clusterid = None
        self.typeInfo['clusterid'] = 'uuid'
        self.required = ["clusterid",]

class disableOutOfBandManagementForClusterResponse (baseResponse):
    typeInfo = {}
    def __init__(self):
        """the out-of-band management action (if issued)"""
        self.action = None
        self.typeInfo['action'] = 'string'
        """the out-of-band management interface address"""
        self.address = None
        self.typeInfo['address'] = 'string'
        """the operation result description"""
        self.description = None
        self.typeInfo['description'] = 'string'
        """the out-of-band management driver for the host"""
        self.driver = None
        self.typeInfo['driver'] = 'string'
        """true if out-of-band management is enabled for the host"""
        self.enabled = None
        self.typeInfo['enabled'] = 'boolean'
        """the ID of the host"""
        self.hostid = None
        self.typeInfo['hostid'] = 'string'
        """the out-of-band management interface password"""
        self.password = None
        self.typeInfo['password'] = 'string'
        """the out-of-band management interface port"""
        self.port = None
        self.typeInfo['port'] = 'string'
        """the out-of-band management interface powerState of the host"""
        self.powerstate = None
        self.typeInfo['powerstate'] = 'powerstate'
        """the operation result"""
        self.status = None
        self.typeInfo['status'] = 'boolean'
        """the out-of-band management interface username"""
        self.username = None
        self.typeInfo['username'] = 'string'

