# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""Test Client for CloudStack API"""
import copy
from listNetworkACLs import listNetworkACLsResponse
from reconnectHost import reconnectHostResponse
from createCondition import createConditionResponse
from copyTemplate import copyTemplateResponse
from listRouters import listRoutersResponse
from listNiciraNvpDeviceNetworks import listNiciraNvpDeviceNetworksResponse
from configureOutOfBandManagement import configureOutOfBandManagementResponse
from addNicToVirtualMachine import addNicToVirtualMachineResponse
from extractVolume import extractVolumeResponse
from listCiscoAsa1000vResources import listCiscoAsa1000vResourcesResponse
from quotaCredits import quotaCreditsResponse
from listNetworkServiceProviders import listNetworkServiceProvidersResponse
from addAccountToProject import addAccountToProjectResponse
from deleteEgressFirewallRule import deleteEgressFirewallRuleResponse
from deleteCiscoNexusVSM import deleteCiscoNexusVSMResponse
from addCluster import addClusterResponse
from listInternalLoadBalancerElements import listInternalLoadBalancerElementsResponse
from listNetworkOfferings import listNetworkOfferingsResponse
from listCiscoVnmcResources import listCiscoVnmcResourcesResponse
from getUploadParamsForVolume import getUploadParamsForVolumeResponse
from updateConfiguration import updateConfigurationResponse
from listHypervisors import listHypervisorsResponse
from createVpnConnection import createVpnConnectionResponse
from listVolumes import listVolumesResponse
from suspendProject import suspendProjectResponse
from deleteLoadBalancer import deleteLoadBalancerResponse
from authorizeSecurityGroupIngress import authorizeSecurityGroupIngressResponse
from listLoadBalancers import listLoadBalancersResponse
from listTrafficTypeImplementors import listTrafficTypeImplementorsResponse
from addNetscalerLoadBalancer import addNetscalerLoadBalancerResponse
from importLdapUsers import importLdapUsersResponse
from listF5LoadBalancers import listF5LoadBalancersResponse
from deleteDomain import deleteDomainResponse
from createPortableIpRange import createPortableIpRangeResponse
from addTrafficMonitor import addTrafficMonitorResponse
from configureNetscalerLoadBalancer import configureNetscalerLoadBalancerResponse
from createTemplate import createTemplateResponse
from listLoadBalancerRuleInstances import listLoadBalancerRuleInstancesResponse
from migrateVolume import migrateVolumeResponse
from deleteLBHealthCheckPolicy import deleteLBHealthCheckPolicyResponse
from updatePhysicalNetwork import updatePhysicalNetworkResponse
from deleteStaticRoute import deleteStaticRouteResponse
from deletePaloAltoFirewall import deletePaloAltoFirewallResponse
from listTrafficMonitors import listTrafficMonitorsResponse
from registerSSHKeyPair import registerSSHKeyPairResponse
from updateCloudToUseObjectStore import updateCloudToUseObjectStoreResponse
from listAutoScaleVmGroups import listAutoScaleVmGroupsResponse
from disableOutOfBandManagementForZone import disableOutOfBandManagementForZoneResponse
from getVMPassword import getVMPasswordResponse
from listInstanceGroups import listInstanceGroupsResponse
from addSecondaryStorage import addSecondaryStorageResponse
from createNetwork import createNetworkResponse
from listProjects import listProjectsResponse
from enableAccount import enableAccountResponse
from destroySystemVm import destroySystemVmResponse
from listPublicIpAddresses import listPublicIpAddressesResponse
from listGuestOsMapping import listGuestOsMappingResponse
from updateRemoteAccessVpn import updateRemoteAccessVpnResponse
from enableStorageMaintenance import enableStorageMaintenanceResponse
from updateLoadBalancer import updateLoadBalancerResponse
from removeFromGlobalLoadBalancerRule import removeFromGlobalLoadBalancerRuleResponse
from listVpnGateways import listVpnGatewaysResponse
from stopRouter import stopRouterResponse
from listClusters import listClustersResponse
from listDedicatedPods import listDedicatedPodsResponse
from createLunOnFiler import createLunOnFilerResponse
from attachVolume import attachVolumeResponse
from updateVPCOffering import updateVPCOfferingResponse
from resetSSHKeyForVirtualMachine import resetSSHKeyForVirtualMachineResponse
from updateRolePermission import updateRolePermissionResponse
from addCiscoAsa1000vResource import addCiscoAsa1000vResourceResponse
from listAutoScalePolicies import listAutoScalePoliciesResponse
from destroyLunOnFiler import destroyLunOnFilerResponse
from cleanVMReservations import cleanVMReservationsResponse
from createAffinityGroup import createAffinityGroupResponse
from addExternalLoadBalancer import addExternalLoadBalancerResponse
from listDeploymentPlanners import listDeploymentPlannersResponse
from listAlerts import listAlertsResponse
from deleteExternalLoadBalancer import deleteExternalLoadBalancerResponse
from deleteTags import deleteTagsResponse
from deleteAccountFromProject import deleteAccountFromProjectResponse
from addBaremetalPxePingServer import addBaremetalPxePingServerResponse
from listCiscoNexusVSMs import listCiscoNexusVSMsResponse
from listPrivateGateways import listPrivateGatewaysResponse
from ldapConfig import ldapConfigResponse
from deletePortableIpRange import deletePortableIpRangeResponse
from updateVmNicIp import updateVmNicIpResponse
from updateRegion import updateRegionResponse
from updateVolume import updateVolumeResponse
from listUcsManagers import listUcsManagersResponse
from quotaIsEnabled import quotaIsEnabledResponse
from listNetworks import listNetworksResponse
from uploadCustomCertificate import uploadCustomCertificateResponse
from listImageStores import listImageStoresResponse
from listCapacity import listCapacityResponse
from createAutoScaleVmProfile import createAutoScaleVmProfileResponse
from createSecurityGroup import createSecurityGroupResponse
from releaseDedicatedGuestVlanRange import releaseDedicatedGuestVlanRangeResponse
from createSSHKeyPair import createSSHKeyPairResponse
from cancelHostMaintenance import cancelHostMaintenanceResponse
from updateServiceOffering import updateServiceOfferingResponse
from listLdapUsers import listLdapUsersResponse
from releaseDedicatedHost import releaseDedicatedHostResponse
from addNuageVspDevice import addNuageVspDeviceResponse
from samlSlo import samlSloResponse
from updateStoragePool import updateStoragePoolResponse
from deleteStorageNetworkIpRange import deleteStorageNetworkIpRangeResponse
from listVirtualRouterElements import listVirtualRouterElementsResponse
from createInternalLoadBalancerElement import createInternalLoadBalancerElementResponse
from deleteFirewallRule import deleteFirewallRuleResponse
from listAndSwitchSamlAccount import listAndSwitchSamlAccountResponse
from addBaremetalHost import addBaremetalHostResponse
from deleteNiciraNvpDevice import deleteNiciraNvpDeviceResponse
from getSolidFireAccountId import getSolidFireAccountIdResponse
from listApis import listApisResponse
from deleteProject import deleteProjectResponse
from removeIpFromNic import removeIpFromNicResponse
from updateHostPassword import updateHostPasswordResponse
from createRole import createRoleResponse
from deleteIpForwardingRule import deleteIpForwardingRuleResponse
from listBigSwitchBcfDevices import listBigSwitchBcfDevicesResponse
from addSwift import addSwiftResponse
from getVirtualMachineUserData import getVirtualMachineUserDataResponse
from deleteStratosphereSsp import deleteStratosphereSspResponse
from createGlobalLoadBalancerRule import createGlobalLoadBalancerRuleResponse
from resizeVolume import resizeVolumeResponse
from listSSHKeyPairs import listSSHKeyPairsResponse
from deleteBrocadeVcsDevice import deleteBrocadeVcsDeviceResponse
from createStaticRoute import createStaticRouteResponse
from listNiciraNvpDevices import listNiciraNvpDevicesResponse
from deleteGlobalLoadBalancerRule import deleteGlobalLoadBalancerRuleResponse
from activateProject import activateProjectResponse
from getSolidFireVolumeAccessGroupId import getSolidFireVolumeAccessGroupIdResponse
from releaseDedicatedZone import releaseDedicatedZoneResponse
from createVMSnapshot import createVMSnapshotResponse
from enableStaticNat import enableStaticNatResponse
from configureF5LoadBalancer import configureF5LoadBalancerResponse
from createIpForwardingRule import createIpForwardingRuleResponse
from updateIpAddress import updateIpAddressResponse
from listBrocadeVcsDeviceNetworks import listBrocadeVcsDeviceNetworksResponse
from listStorageProviders import listStorageProvidersResponse
from listRegions import listRegionsResponse
from searchLdap import searchLdapResponse
from createPool import createPoolResponse
from listNetworkACLLists import listNetworkACLListsResponse
from updateDiskOffering import updateDiskOfferingResponse
from listUcsProfiles import listUcsProfilesResponse
from addPaloAltoFirewall import addPaloAltoFirewallResponse
from recoverVirtualMachine import recoverVirtualMachineResponse
from listVolumesOnFiler import listVolumesOnFilerResponse
from enableOutOfBandManagementForCluster import enableOutOfBandManagementForClusterResponse
from listCapabilities import listCapabilitiesResponse
from releaseDedicatedCluster import releaseDedicatedClusterResponse
from getPathForVolume import getPathForVolumeResponse
from listRolePermissions import listRolePermissionsResponse
from updateVPC import updateVPCResponse
from startInternalLoadBalancerVM import startInternalLoadBalancerVMResponse
from associateUcsProfileToBlade import associateUcsProfileToBladeResponse
from listProjectAccounts import listProjectAccountsResponse
from updateAutoScaleVmProfile import updateAutoScaleVmProfileResponse
from updatePortForwardingRule import updatePortForwardingRuleResponse
from listDedicatedHosts import listDedicatedHostsResponse
from addBigSwitchBcfDevice import addBigSwitchBcfDeviceResponse
from listPortForwardingRules import listPortForwardingRulesResponse
from listTemplatePermissions import listTemplatePermissionsResponse
from createStorageNetworkIpRange import createStorageNetworkIpRangeResponse
from addGloboDnsHost import addGloboDnsHostResponse
from uploadSslCert import uploadSslCertResponse
from queryAsyncJobResult import queryAsyncJobResultResponse
from createLoadBalancer import createLoadBalancerResponse
from cancelStorageMaintenance import cancelStorageMaintenanceResponse
from removeVmwareDc import removeVmwareDcResponse
from deployVirtualMachine import deployVirtualMachineResponse
from deletePod import deletePodResponse
from revokeSecurityGroupEgress import revokeSecurityGroupEgressResponse
from createNetworkACLList import createNetworkACLListResponse
from deleteCondition import deleteConditionResponse
from deleteSecondaryStagingStore import deleteSecondaryStagingStoreResponse
from createPortForwardingRule import createPortForwardingRuleResponse
from listNetscalerLoadBalancers import listNetscalerLoadBalancersResponse
from createVPCOffering import createVPCOfferingResponse
from createEgressFirewallRule import createEgressFirewallRuleResponse
from destroyRouter import destroyRouterResponse
from deleteAlerts import deleteAlertsResponse
from updateLBStickinessPolicy import updateLBStickinessPolicyResponse
from updateSnapshotPolicy import updateSnapshotPolicyResponse
from listUsageRecords import listUsageRecordsResponse
from assignToGlobalLoadBalancerRule import assignToGlobalLoadBalancerRuleResponse
from listOvsElements import listOvsElementsResponse
from updateTrafficType import updateTrafficTypeResponse
from listPods import listPodsResponse
from listLdapConfigurations import listLdapConfigurationsResponse
from enableUser import enableUserResponse
from listOsCategories import listOsCategoriesResponse
from addSrxFirewall import addSrxFirewallResponse
from addNiciraNvpDevice import addNiciraNvpDeviceResponse
from updateNetworkACLItem import updateNetworkACLItemResponse
from createInstanceGroup import createInstanceGroupResponse
from addIpToNic import addIpToNicResponse
from deleteNetworkACLList import deleteNetworkACLListResponse
from listLunsOnFiler import listLunsOnFilerResponse
from updateAccount import updateAccountResponse
from deleteNetworkDevice import deleteNetworkDeviceResponse
from listSnapshotPolicies import listSnapshotPoliciesResponse
from configureInternalLoadBalancerElement import configureInternalLoadBalancerElementResponse
from modifyPool import modifyPoolResponse
from releaseHostReservation import releaseHostReservationResponse
from deleteSSHKeyPair import deleteSSHKeyPairResponse
from createDomain import createDomainResponse
from deleteSnapshotPolicies import deleteSnapshotPoliciesResponse
from listLBHealthCheckPolicies import listLBHealthCheckPoliciesResponse
from listEvents import listEventsResponse
from assignCertToLoadBalancer import assignCertToLoadBalancerResponse
from quotaEmailTemplateList import quotaEmailTemplateListResponse
from addHost import addHostResponse
from updateNuageVspDevice import updateNuageVspDeviceResponse
from listDedicatedClusters import listDedicatedClustersResponse
from destroyVolumeOnFiler import destroyVolumeOnFilerResponse
from changeOutOfBandManagementPassword import changeOutOfBandManagementPasswordResponse
from deleteVpnGateway import deleteVpnGatewayResponse
from expungeVirtualMachine import expungeVirtualMachineResponse
from addNetworkDevice import addNetworkDeviceResponse
from createAutoScaleVmGroup import createAutoScaleVmGroupResponse
from deleteNetworkServiceProvider import deleteNetworkServiceProviderResponse
from rebootRouter import rebootRouterResponse
from listRoles import listRolesResponse
from createLBHealthCheckPolicy import createLBHealthCheckPolicyResponse
from archiveEvents import archiveEventsResponse
from listConfigurations import listConfigurationsResponse
from updateHost import updateHostResponse
from listProjectInvitations import listProjectInvitationsResponse
from listBrocadeVcsDevices import listBrocadeVcsDevicesResponse
from deleteIso import deleteIsoResponse
from removeGuestOsMapping import removeGuestOsMappingResponse
from createVpnCustomerGateway import createVpnCustomerGatewayResponse
from listTrafficTypes import listTrafficTypesResponse
from updateResourceLimit import updateResourceLimitResponse
from lockAccount import lockAccountResponse
from updateRole import updateRoleResponse
from deleteTrafficMonitor import deleteTrafficMonitorResponse
from createUser import createUserResponse
from deleteAutoScalePolicy import deleteAutoScalePolicyResponse
from deleteSrxFirewall import deleteSrxFirewallResponse
from listNetworkIsolationMethods import listNetworkIsolationMethodsResponse
from updateNetworkACLList import updateNetworkACLListResponse
from listDiskOfferings import listDiskOfferingsResponse
from detachVolume import detachVolumeResponse
from deleteUser import deleteUserResponse
from deleteNetworkACL import deleteNetworkACLResponse
from listSnapshots import listSnapshotsResponse
from deleteVPC import deleteVPCResponse
from deleteSecurityGroup import deleteSecurityGroupResponse
from listCounters import listCountersResponse
from deleteSslCert import deleteSslCertResponse
from updateHypervisorCapabilities import updateHypervisorCapabilitiesResponse
from createPhysicalNetwork import createPhysicalNetworkResponse
from updateLoadBalancerRule import updateLoadBalancerRuleResponse
from createRolePermission import createRolePermissionResponse
from enableOutOfBandManagementForHost import enableOutOfBandManagementForHostResponse
from deleteTemplate import deleteTemplateResponse
from listHypervisorCapabilities import listHypervisorCapabilitiesResponse
from listTags import listTagsResponse
from deleteVpnCustomerGateway import deleteVpnCustomerGatewayResponse
from deleteCiscoVnmcResource import deleteCiscoVnmcResourceResponse
from listIsoPermissions import listIsoPermissionsResponse
from quotaTariffUpdate import quotaTariffUpdateResponse
from createVirtualRouterElement import createVirtualRouterElementResponse
from updateAutoScalePolicy import updateAutoScalePolicyResponse
from releaseDedicatedPod import releaseDedicatedPodResponse
from createVpnGateway import createVpnGatewayResponse
from dedicateZone import dedicateZoneResponse
from deleteCounter import deleteCounterResponse
from dedicateCluster import dedicateClusterResponse
from addExternalFirewall import addExternalFirewallResponse
from linkDomainToLdap import linkDomainToLdapResponse
from updateStorageNetworkIpRange import updateStorageNetworkIpRangeResponse
from listAsyncJobs import listAsyncJobsResponse
from addBrocadeVcsDevice import addBrocadeVcsDeviceResponse
from quotaTariffList import quotaTariffListResponse
from listUsageTypes import listUsageTypesResponse
from listSecondaryStagingStores import listSecondaryStagingStoresResponse
from listF5LoadBalancerNetworks import listF5LoadBalancerNetworksResponse
from createVlanIpRange import createVlanIpRangeResponse
from addImageStore import addImageStoreResponse
from ldapCreateAccount import ldapCreateAccountResponse
from findHostsForMigration import findHostsForMigrationResponse
from dedicatePod import dedicatePodResponse
from addF5LoadBalancer import addF5LoadBalancerResponse
from deleteAutoScaleVmGroup import deleteAutoScaleVmGroupResponse
from updateGlobalLoadBalancerRule import updateGlobalLoadBalancerRuleResponse
from listRemoteAccessVpns import listRemoteAccessVpnsResponse
from registerTemplate import registerTemplateResponse
from listAffinityGroupTypes import listAffinityGroupTypesResponse
from createServiceInstance import createServiceInstanceResponse
from deleteNetworkOffering import deleteNetworkOfferingResponse
from deleteBaremetalRct import deleteBaremetalRctResponse
from authorizeSecurityGroupEgress import authorizeSecurityGroupEgressResponse
from disableAutoScaleVmGroup import disableAutoScaleVmGroupResponse
from disableOutOfBandManagementForCluster import disableOutOfBandManagementForClusterResponse
from listVpnCustomerGateways import listVpnCustomerGatewaysResponse
from deleteRolePermission import deleteRolePermissionResponse
from authorizeSamlSso import authorizeSamlSsoResponse
from createAccount import createAccountResponse
from prepareHostForMaintenance import prepareHostForMaintenanceResponse
from listNuageVspDevices import listNuageVspDevicesResponse
from listIdps import listIdpsResponse
from addOpenDaylightController import addOpenDaylightControllerResponse
from updateEgressFirewallRule import updateEgressFirewallRuleResponse
from getVolumeiScsiName import getVolumeiScsiNameResponse
from deletePrivateGateway import deletePrivateGatewayResponse
from createVolumeOnFiler import createVolumeOnFilerResponse
from updateGuestOs import updateGuestOsResponse
from stopInternalLoadBalancerVM import stopInternalLoadBalancerVMResponse
from createSecondaryStagingStore import createSecondaryStagingStoreResponse
from deleteTrafficType import deleteTrafficTypeResponse
from generateUsageRecords import generateUsageRecordsResponse
from deleteLoadBalancerRule import deleteLoadBalancerRuleResponse
from getApiLimit import getApiLimitResponse
from attachIso import attachIsoResponse
from deletePortForwardingRule import deletePortForwardingRuleResponse
from getUser import getUserResponse
from listDomains import listDomainsResponse
from listLoadBalancerRules import listLoadBalancerRulesResponse
from getVolumeSnapshotDetails import getVolumeSnapshotDetailsResponse
from listPaloAltoFirewalls import listPaloAltoFirewallsResponse
from deleteEvents import deleteEventsResponse
from removeCertFromLoadBalancer import removeCertFromLoadBalancerResponse
from configureSrxFirewall import configureSrxFirewallResponse
from deleteZone import deleteZoneResponse
from updateProjectInvitation import updateProjectInvitationResponse
from deleteVolume import deleteVolumeResponse
from createTags import createTagsResponse
from enableAutoScaleVmGroup import enableAutoScaleVmGroupResponse
from listOpenDaylightControllers import listOpenDaylightControllersResponse
from listResourceDetails import listResourceDetailsResponse
from listPools import listPoolsResponse
from deleteLdapConfiguration import deleteLdapConfigurationResponse
from updateCluster import updateClusterResponse
from removeVpnUser import removeVpnUserResponse
from listSrxFirewalls import listSrxFirewallsResponse
from scaleVirtualMachine import scaleVirtualMachineResponse
from listPaloAltoFirewallNetworks import listPaloAltoFirewallNetworksResponse
from releasePublicIpRange import releasePublicIpRangeResponse
from listSamlAuthorization import listSamlAuthorizationResponse
from listTemplates import listTemplatesResponse
from listDedicatedGuestVlanRanges import listDedicatedGuestVlanRangesResponse
from updateVpnCustomerGateway import updateVpnCustomerGatewayResponse
from updateIsoPermissions import updateIsoPermissionsResponse
from login import loginResponse
from stopSystemVm import stopSystemVmResponse
from restartNetwork import restartNetworkResponse
from prepareTemplate import prepareTemplateResponse
from removeGuestOs import removeGuestOsResponse
from changeServiceForRouter import changeServiceForRouterResponse
from rebootVirtualMachine import rebootVirtualMachineResponse
from listGlobalLoadBalancerRules import listGlobalLoadBalancerRulesResponse
from removeRawUsageRecords import removeRawUsageRecordsResponse
from notifyBaremetalProvisionDone import notifyBaremetalProvisionDoneResponse
from listLBStickinessPolicies import listLBStickinessPoliciesResponse
from updateZone import updateZoneResponse
from enableCiscoNexusVSM import enableCiscoNexusVSMResponse
from ldapRemove import ldapRemoveResponse
from listSecurityGroups import listSecurityGroupsResponse
from dedicateGuestVlanRange import dedicateGuestVlanRangeResponse
from listFirewallRules import listFirewallRulesResponse
from updateVMAffinityGroup import updateVMAffinityGroupResponse
from configurePaloAltoFirewall import configurePaloAltoFirewallResponse
from quotaSummary import quotaSummaryResponse
from deleteVpnConnection import deleteVpnConnectionResponse
from listAffinityGroups import listAffinityGroupsResponse
from updateUser import updateUserResponse
from updateVpnConnection import updateVpnConnectionResponse
from deleteDiskOffering import deleteDiskOfferingResponse
from updateVpnGateway import updateVpnGatewayResponse
from startSystemVm import startSystemVmResponse
from deleteF5LoadBalancer import deleteF5LoadBalancerResponse
from updateProject import updateProjectResponse
from archiveAlerts import archiveAlertsResponse
from createZone import createZoneResponse
from listBaremetalPxeServers import listBaremetalPxeServersResponse
from deleteNetwork import deleteNetworkResponse
from listStaticRoutes import listStaticRoutesResponse
from addCiscoVnmcResource import addCiscoVnmcResourceResponse
from deleteNetscalerLoadBalancer import deleteNetscalerLoadBalancerResponse
from changeServiceForSystemVm import changeServiceForSystemVmResponse
from listNics import listNicsResponse
from listSrxFirewallNetworks import listSrxFirewallNetworksResponse
from createStoragePool import createStoragePoolResponse
from removeRegion import removeRegionResponse
from deleteUcsManager import deleteUcsManagerResponse
from listBaremetalDhcp import listBaremetalDhcpResponse
from addTrafficType import addTrafficTypeResponse
from listSwifts import listSwiftsResponse
from deleteNuageVspDevice import deleteNuageVspDeviceResponse
from updateTemplate import updateTemplateResponse
from disableUser import disableUserResponse
from configureVirtualRouterElement import configureVirtualRouterElementResponse
from createSnapshotPolicy import createSnapshotPolicyResponse
from deleteProjectInvitation import deleteProjectInvitationResponse
from quotaEmailTemplateUpdate import quotaEmailTemplateUpdateResponse
from addBaremetalRct import addBaremetalRctResponse
from updateInstanceGroup import updateInstanceGroupResponse
from migrateSystemVm import migrateSystemVmResponse
from createServiceOffering import createServiceOfferingResponse
from removeNicFromVirtualMachine import removeNicFromVirtualMachineResponse
from deleteCiscoAsa1000vResource import deleteCiscoAsa1000vResourceResponse
from revokeSecurityGroupIngress import revokeSecurityGroupIngressResponse
from updateDefaultNicForVirtualMachine import updateDefaultNicForVirtualMachineResponse
from disableStaticNat import disableStaticNatResponse
from listExternalFirewalls import listExternalFirewallsResponse
from createNetworkACL import createNetworkACLResponse
from createPod import createPodResponse
from createVPC import createVPCResponse
from listOsTypes import listOsTypesResponse
from addBaremetalPxeKickStartServer import addBaremetalPxeKickStartServerResponse
from listSslCerts import listSslCertsResponse
from quotaBalance import quotaBalanceResponse
from registerIso import registerIsoResponse
from addResourceDetail import addResourceDetailResponse
from disassociateIpAddress import disassociateIpAddressResponse
from listZones import listZonesResponse
from issueOutOfBandManagementPowerAction import issueOutOfBandManagementPowerActionResponse
from listExternalLoadBalancers import listExternalLoadBalancersResponse
from createVolume import createVolumeResponse
from resetPasswordForVirtualMachine import resetPasswordForVirtualMachineResponse
from assignToLoadBalancerRule import assignToLoadBalancerRuleResponse
from startRouter import startRouterResponse
from listUcsBlades import listUcsBladesResponse
from updateGuestOsMapping import updateGuestOsMappingResponse
from extractIso import extractIsoResponse
from removeResourceDetail import removeResourceDetailResponse
from changeServiceForVirtualMachine import changeServiceForVirtualMachineResponse
from deleteRemoteAccessVpn import deleteRemoteAccessVpnResponse
from addVmwareDc import addVmwareDcResponse
from deleteImageStore import deleteImageStoreResponse
from deleteVlanIpRange import deleteVlanIpRangeResponse
from listStoragePools import listStoragePoolsResponse
from resetVpnConnection import resetVpnConnectionResponse
from listStorageTags import listStorageTagsResponse
from createRemoteAccessVpn import createRemoteAccessVpnResponse
from extractTemplate import extractTemplateResponse
from startVirtualMachine import startVirtualMachineResponse
from listSystemVms import listSystemVmsResponse
from detachIso import detachIsoResponse
from deleteServiceOffering import deleteServiceOfferingResponse
from deleteAccount import deleteAccountResponse
from listNetworkDevice import listNetworkDeviceResponse
from deleteBigSwitchBcfDevice import deleteBigSwitchBcfDeviceResponse
from associateIpAddress import associateIpAddressResponse
from disableAccount import disableAccountResponse
from migrateVirtualMachine import migrateVirtualMachineResponse
from getUploadParamsForTemplate import getUploadParamsForTemplateResponse
from updateDomain import updateDomainResponse
from listVMSnapshot import listVMSnapshotResponse
from listDedicatedZones import listDedicatedZonesResponse
from removeFromLoadBalancerRule import removeFromLoadBalancerRuleResponse
from addImageStoreS3 import addImageStoreS3Response
from resetApiLimit import resetApiLimitResponse
from registerUserKeys import registerUserKeysResponse
from disableOutOfBandManagementForHost import disableOutOfBandManagementForHostResponse
from addVpnUser import addVpnUserResponse
from listVPCs import listVPCsResponse
from assignVirtualMachine import assignVirtualMachineResponse
from updateLBHealthCheckPolicy import updateLBHealthCheckPolicyResponse
from updateFirewallRule import updateFirewallRuleResponse
from listConditions import listConditionsResponse
from createPrivateGateway import createPrivateGatewayResponse
from deleteLBStickinessPolicy import deleteLBStickinessPolicyResponse
from updateVirtualMachine import updateVirtualMachineResponse
from getSPMetadata import getSPMetadataResponse
from getSolidFireVolumeSize import getSolidFireVolumeSizeResponse
from listResourceLimits import listResourceLimitsResponse
from listServiceOfferings import listServiceOfferingsResponse
from addUcsManager import addUcsManagerResponse
from disableCiscoNexusVSM import disableCiscoNexusVSMResponse
from deleteVMSnapshot import deleteVMSnapshotResponse
from deleteAutoScaleVmProfile import deleteAutoScaleVmProfileResponse
from deleteStoragePool import deleteStoragePoolResponse
from samlSso import samlSsoResponse
from deleteRole import deleteRoleResponse
from deleteSnapshot import deleteSnapshotResponse
from createProject import createProjectResponse
from createLoadBalancerRule import createLoadBalancerRuleResponse
from createAutoScalePolicy import createAutoScalePolicyResponse
from restoreVirtualMachine import restoreVirtualMachineResponse
from logout import logoutResponse
from listEventTypes import listEventTypesResponse
from deleteAffinityGroup import deleteAffinityGroupResponse
from createNetworkOffering import createNetworkOfferingResponse
from copyIso import copyIsoResponse
from dedicatePublicIpRange import dedicatePublicIpRangeResponse
from addGuestOsMapping import addGuestOsMappingResponse
from listDomainChildren import listDomainChildrenResponse
from uploadVolume import uploadVolumeResponse
from listAutoScaleVmProfiles import listAutoScaleVmProfilesResponse
from createLBStickinessPolicy import createLBStickinessPolicyResponse
from migrateVirtualMachineWithVolume import migrateVirtualMachineWithVolumeResponse
from stopVirtualMachine import stopVirtualMachineResponse
from createCounter import createCounterResponse
from listAccounts import listAccountsResponse
from createSnapshot import createSnapshotResponse
from updateIso import updateIsoResponse
from listPortableIpRanges import listPortableIpRangesResponse
from configureOvsElement import configureOvsElementResponse
from listIpForwardingRules import listIpForwardingRulesResponse
from updateNetwork import updateNetworkResponse
from destroyVirtualMachine import destroyVirtualMachineResponse
from enableOutOfBandManagementForZone import enableOutOfBandManagementForZoneResponse
from dissociateLun import dissociateLunResponse
from dedicateHost import dedicateHostResponse
from listHostTags import listHostTagsResponse
from addRegion import addRegionResponse
from createDiskOffering import createDiskOfferingResponse
from getCloudIdentifier import getCloudIdentifierResponse
from listNetscalerLoadBalancerNetworks import listNetscalerLoadBalancerNetworksResponse
from deleteExternalFirewall import deleteExternalFirewallResponse
from createFirewallRule import createFirewallRuleResponse
from listInternalLoadBalancerVMs import listInternalLoadBalancerVMsResponse
from updateResourceCount import updateResourceCountResponse
from addNetworkServiceProvider import addNetworkServiceProviderResponse
from rebootSystemVm import rebootSystemVmResponse
from revertToVMSnapshot import revertToVMSnapshotResponse
from markDefaultZoneForAccount import markDefaultZoneForAccountResponse
from lockUser import lockUserResponse
from quotaStatement import quotaStatementResponse
from addLdapConfiguration import addLdapConfigurationResponse
from listVirtualMachines import listVirtualMachinesResponse
from restartVPC import restartVPCResponse
from replaceNetworkACLList import replaceNetworkACLListResponse
from generateAlert import generateAlertResponse
from scaleSystemVm import scaleSystemVmResponse
from listEgressFirewallRules import listEgressFirewallRulesResponse
from updateAutoScaleVmGroup import updateAutoScaleVmGroupResponse
from listHosts import listHostsResponse
from updateTemplatePermissions import updateTemplatePermissionsResponse
from listVlanIpRanges import listVlanIpRangesResponse
from listBaremetalRct import listBaremetalRctResponse
from listPhysicalNetworks import listPhysicalNetworksResponse
from listStorageNetworkIpRange import listStorageNetworkIpRangeResponse
from listVpnConnections import listVpnConnectionsResponse
from deleteHost import deleteHostResponse
from listVPCOfferings import listVPCOfferingsResponse
from updateNetworkOffering import updateNetworkOfferingResponse
from deletePhysicalNetwork import deletePhysicalNetworkResponse
from deleteInstanceGroup import deleteInstanceGroupResponse
from addBaremetalDhcp import addBaremetalDhcpResponse
from deleteVPCOffering import deleteVPCOfferingResponse
from quotaUpdate import quotaUpdateResponse
from associateLun import associateLunResponse
from listVpnUsers import listVpnUsersResponse
from updatePod import updatePodResponse
from deletePool import deletePoolResponse
from deleteOpenDaylightController import deleteOpenDaylightControllerResponse
from listVmwareDcs import listVmwareDcsResponse
from deleteCluster import deleteClusterResponse
from updateNetworkServiceProvider import updateNetworkServiceProviderResponse
from findStoragePoolsForMigration import findStoragePoolsForMigrationResponse
from listUsers import listUsersResponse
from upgradeRouterTemplate import upgradeRouterTemplateResponse
from listSupportedNetworkServices import listSupportedNetworkServicesResponse
from addStratosphereSsp import addStratosphereSspResponse
from addGuestOs import addGuestOsResponse
from listIsos import listIsosResponse
from revertSnapshot import revertSnapshotResponse
class CloudStackAPIClient(object):
    def __init__(self, connection):
        self.connection = connection
        self._id = None

    def __copy__(self):
        return CloudStackAPIClient(copy.copy(self.connection))

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, identifier):
        self._id = identifier

    def listNetworkACLs(self, command, method="GET"):
        response = listNetworkACLsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def reconnectHost(self, command, method="GET"):
        response = reconnectHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createCondition(self, command, method="GET"):
        response = createConditionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def copyTemplate(self, command, method="GET"):
        response = copyTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listRouters(self, command, method="GET"):
        response = listRoutersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNiciraNvpDeviceNetworks(self, command, method="GET"):
        response = listNiciraNvpDeviceNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configureOutOfBandManagement(self, command, method="GET"):
        response = configureOutOfBandManagementResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addNicToVirtualMachine(self, command, method="GET"):
        response = addNicToVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def extractVolume(self, command, method="GET"):
        response = extractVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listCiscoAsa1000vResources(self, command, method="GET"):
        response = listCiscoAsa1000vResourcesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaCredits(self, command, method="GET"):
        response = quotaCreditsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetworkServiceProviders(self, command, method="GET"):
        response = listNetworkServiceProvidersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addAccountToProject(self, command, method="GET"):
        response = addAccountToProjectResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteEgressFirewallRule(self, command, method="GET"):
        response = deleteEgressFirewallRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteCiscoNexusVSM(self, command, method="GET"):
        response = deleteCiscoNexusVSMResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addCluster(self, command, method="GET"):
        response = addClusterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listInternalLoadBalancerElements(self, command, method="GET"):
        response = listInternalLoadBalancerElementsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetworkOfferings(self, command, method="GET"):
        response = listNetworkOfferingsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listCiscoVnmcResources(self, command, method="GET"):
        response = listCiscoVnmcResourcesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getUploadParamsForVolume(self, command, method="GET"):
        response = getUploadParamsForVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateConfiguration(self, command, method="GET"):
        response = updateConfigurationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listHypervisors(self, command, method="GET"):
        response = listHypervisorsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVpnConnection(self, command, method="GET"):
        response = createVpnConnectionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVolumes(self, command, method="GET"):
        response = listVolumesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def suspendProject(self, command, method="GET"):
        response = suspendProjectResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteLoadBalancer(self, command, method="GET"):
        response = deleteLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def authorizeSecurityGroupIngress(self, command, method="GET"):
        response = authorizeSecurityGroupIngressResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLoadBalancers(self, command, method="GET"):
        response = listLoadBalancersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listTrafficTypeImplementors(self, command, method="GET"):
        response = listTrafficTypeImplementorsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addNetscalerLoadBalancer(self, command, method="GET"):
        response = addNetscalerLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def importLdapUsers(self, command, method="GET"):
        response = importLdapUsersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listF5LoadBalancers(self, command, method="GET"):
        response = listF5LoadBalancersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteDomain(self, command, method="GET"):
        response = deleteDomainResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createPortableIpRange(self, command, method="GET"):
        response = createPortableIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addTrafficMonitor(self, command, method="GET"):
        response = addTrafficMonitorResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configureNetscalerLoadBalancer(self, command, method="GET"):
        response = configureNetscalerLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createTemplate(self, command, method="GET"):
        response = createTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLoadBalancerRuleInstances(self, command, method="GET"):
        response = listLoadBalancerRuleInstancesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def migrateVolume(self, command, method="GET"):
        response = migrateVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteLBHealthCheckPolicy(self, command, method="GET"):
        response = deleteLBHealthCheckPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updatePhysicalNetwork(self, command, method="GET"):
        response = updatePhysicalNetworkResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteStaticRoute(self, command, method="GET"):
        response = deleteStaticRouteResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deletePaloAltoFirewall(self, command, method="GET"):
        response = deletePaloAltoFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listTrafficMonitors(self, command, method="GET"):
        response = listTrafficMonitorsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def registerSSHKeyPair(self, command, method="GET"):
        response = registerSSHKeyPairResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateCloudToUseObjectStore(self, command, method="GET"):
        response = updateCloudToUseObjectStoreResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAutoScaleVmGroups(self, command, method="GET"):
        response = listAutoScaleVmGroupsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableOutOfBandManagementForZone(self, command, method="GET"):
        response = disableOutOfBandManagementForZoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getVMPassword(self, command, method="GET"):
        response = getVMPasswordResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listInstanceGroups(self, command, method="GET"):
        response = listInstanceGroupsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addSecondaryStorage(self, command, method="GET"):
        response = addSecondaryStorageResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createNetwork(self, command, method="GET"):
        response = createNetworkResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listProjects(self, command, method="GET"):
        response = listProjectsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableAccount(self, command, method="GET"):
        response = enableAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def destroySystemVm(self, command, method="GET"):
        response = destroySystemVmResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPublicIpAddresses(self, command, method="GET"):
        response = listPublicIpAddressesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listGuestOsMapping(self, command, method="GET"):
        response = listGuestOsMappingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateRemoteAccessVpn(self, command, method="GET"):
        response = updateRemoteAccessVpnResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableStorageMaintenance(self, command, method="GET"):
        response = enableStorageMaintenanceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateLoadBalancer(self, command, method="GET"):
        response = updateLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeFromGlobalLoadBalancerRule(self, command, method="GET"):
        response = removeFromGlobalLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVpnGateways(self, command, method="GET"):
        response = listVpnGatewaysResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def stopRouter(self, command, method="GET"):
        response = stopRouterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listClusters(self, command, method="GET"):
        response = listClustersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDedicatedPods(self, command, method="GET"):
        response = listDedicatedPodsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createLunOnFiler(self, command, method="GET"):
        response = createLunOnFilerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def attachVolume(self, command, method="GET"):
        response = attachVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVPCOffering(self, command, method="GET"):
        response = updateVPCOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def resetSSHKeyForVirtualMachine(self, command, method="GET"):
        response = resetSSHKeyForVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateRolePermission(self, command, method="GET"):
        response = updateRolePermissionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addCiscoAsa1000vResource(self, command, method="GET"):
        response = addCiscoAsa1000vResourceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAutoScalePolicies(self, command, method="GET"):
        response = listAutoScalePoliciesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def destroyLunOnFiler(self, command, method="GET"):
        response = destroyLunOnFilerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def cleanVMReservations(self, command, method="GET"):
        response = cleanVMReservationsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createAffinityGroup(self, command, method="GET"):
        response = createAffinityGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addExternalLoadBalancer(self, command, method="GET"):
        response = addExternalLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDeploymentPlanners(self, command, method="GET"):
        response = listDeploymentPlannersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAlerts(self, command, method="GET"):
        response = listAlertsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteExternalLoadBalancer(self, command, method="GET"):
        response = deleteExternalLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteTags(self, command, method="GET"):
        response = deleteTagsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteAccountFromProject(self, command, method="GET"):
        response = deleteAccountFromProjectResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addBaremetalPxePingServer(self, command, method="GET"):
        response = addBaremetalPxePingServerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listCiscoNexusVSMs(self, command, method="GET"):
        response = listCiscoNexusVSMsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPrivateGateways(self, command, method="GET"):
        response = listPrivateGatewaysResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def ldapConfig(self, command, method="GET"):
        response = ldapConfigResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deletePortableIpRange(self, command, method="GET"):
        response = deletePortableIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVmNicIp(self, command, method="GET"):
        response = updateVmNicIpResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateRegion(self, command, method="GET"):
        response = updateRegionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVolume(self, command, method="GET"):
        response = updateVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listUcsManagers(self, command, method="GET"):
        response = listUcsManagersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaIsEnabled(self, command, method="GET"):
        response = quotaIsEnabledResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetworks(self, command, method="GET"):
        response = listNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def uploadCustomCertificate(self, command, method="GET"):
        response = uploadCustomCertificateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listImageStores(self, command, method="GET"):
        response = listImageStoresResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listCapacity(self, command, method="GET"):
        response = listCapacityResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createAutoScaleVmProfile(self, command, method="GET"):
        response = createAutoScaleVmProfileResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createSecurityGroup(self, command, method="GET"):
        response = createSecurityGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def releaseDedicatedGuestVlanRange(self, command, method="GET"):
        response = releaseDedicatedGuestVlanRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createSSHKeyPair(self, command, method="GET"):
        response = createSSHKeyPairResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def cancelHostMaintenance(self, command, method="GET"):
        response = cancelHostMaintenanceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateServiceOffering(self, command, method="GET"):
        response = updateServiceOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLdapUsers(self, command, method="GET"):
        response = listLdapUsersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def releaseDedicatedHost(self, command, method="GET"):
        response = releaseDedicatedHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addNuageVspDevice(self, command, method="GET"):
        response = addNuageVspDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def samlSlo(self, command, method="GET"):
        response = samlSloResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateStoragePool(self, command, method="GET"):
        response = updateStoragePoolResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteStorageNetworkIpRange(self, command, method="GET"):
        response = deleteStorageNetworkIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVirtualRouterElements(self, command, method="GET"):
        response = listVirtualRouterElementsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createInternalLoadBalancerElement(self, command, method="GET"):
        response = createInternalLoadBalancerElementResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteFirewallRule(self, command, method="GET"):
        response = deleteFirewallRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAndSwitchSamlAccount(self, command, method="GET"):
        response = listAndSwitchSamlAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addBaremetalHost(self, command, method="GET"):
        response = addBaremetalHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNiciraNvpDevice(self, command, method="GET"):
        response = deleteNiciraNvpDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getSolidFireAccountId(self, command, method="GET"):
        response = getSolidFireAccountIdResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listApis(self, command, method="GET"):
        response = listApisResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteProject(self, command, method="GET"):
        response = deleteProjectResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeIpFromNic(self, command, method="GET"):
        response = removeIpFromNicResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateHostPassword(self, command, method="GET"):
        response = updateHostPasswordResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createRole(self, command, method="GET"):
        response = createRoleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteIpForwardingRule(self, command, method="GET"):
        response = deleteIpForwardingRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listBigSwitchBcfDevices(self, command, method="GET"):
        response = listBigSwitchBcfDevicesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addSwift(self, command, method="GET"):
        response = addSwiftResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getVirtualMachineUserData(self, command, method="GET"):
        response = getVirtualMachineUserDataResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteStratosphereSsp(self, command, method="GET"):
        response = deleteStratosphereSspResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createGlobalLoadBalancerRule(self, command, method="GET"):
        response = createGlobalLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def resizeVolume(self, command, method="GET"):
        response = resizeVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSSHKeyPairs(self, command, method="GET"):
        response = listSSHKeyPairsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteBrocadeVcsDevice(self, command, method="GET"):
        response = deleteBrocadeVcsDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createStaticRoute(self, command, method="GET"):
        response = createStaticRouteResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNiciraNvpDevices(self, command, method="GET"):
        response = listNiciraNvpDevicesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteGlobalLoadBalancerRule(self, command, method="GET"):
        response = deleteGlobalLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def activateProject(self, command, method="GET"):
        response = activateProjectResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getSolidFireVolumeAccessGroupId(self, command, method="GET"):
        response = getSolidFireVolumeAccessGroupIdResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def releaseDedicatedZone(self, command, method="GET"):
        response = releaseDedicatedZoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVMSnapshot(self, command, method="GET"):
        response = createVMSnapshotResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableStaticNat(self, command, method="GET"):
        response = enableStaticNatResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configureF5LoadBalancer(self, command, method="GET"):
        response = configureF5LoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createIpForwardingRule(self, command, method="GET"):
        response = createIpForwardingRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateIpAddress(self, command, method="GET"):
        response = updateIpAddressResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listBrocadeVcsDeviceNetworks(self, command, method="GET"):
        response = listBrocadeVcsDeviceNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listStorageProviders(self, command, method="GET"):
        response = listStorageProvidersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listRegions(self, command, method="GET"):
        response = listRegionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def searchLdap(self, command, method="GET"):
        response = searchLdapResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createPool(self, command, method="GET"):
        response = createPoolResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetworkACLLists(self, command, method="GET"):
        response = listNetworkACLListsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateDiskOffering(self, command, method="GET"):
        response = updateDiskOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listUcsProfiles(self, command, method="GET"):
        response = listUcsProfilesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addPaloAltoFirewall(self, command, method="GET"):
        response = addPaloAltoFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def recoverVirtualMachine(self, command, method="GET"):
        response = recoverVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVolumesOnFiler(self, command, method="GET"):
        response = listVolumesOnFilerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableOutOfBandManagementForCluster(self, command, method="GET"):
        response = enableOutOfBandManagementForClusterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listCapabilities(self, command, method="GET"):
        response = listCapabilitiesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def releaseDedicatedCluster(self, command, method="GET"):
        response = releaseDedicatedClusterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getPathForVolume(self, command, method="GET"):
        response = getPathForVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listRolePermissions(self, command, method="GET"):
        response = listRolePermissionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVPC(self, command, method="GET"):
        response = updateVPCResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def startInternalLoadBalancerVM(self, command, method="GET"):
        response = startInternalLoadBalancerVMResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def associateUcsProfileToBlade(self, command, method="GET"):
        response = associateUcsProfileToBladeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listProjectAccounts(self, command, method="GET"):
        response = listProjectAccountsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateAutoScaleVmProfile(self, command, method="GET"):
        response = updateAutoScaleVmProfileResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updatePortForwardingRule(self, command, method="GET"):
        response = updatePortForwardingRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDedicatedHosts(self, command, method="GET"):
        response = listDedicatedHostsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addBigSwitchBcfDevice(self, command, method="GET"):
        response = addBigSwitchBcfDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPortForwardingRules(self, command, method="GET"):
        response = listPortForwardingRulesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listTemplatePermissions(self, command, method="GET"):
        response = listTemplatePermissionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createStorageNetworkIpRange(self, command, method="GET"):
        response = createStorageNetworkIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addGloboDnsHost(self, command, method="GET"):
        response = addGloboDnsHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def uploadSslCert(self, command, method="GET"):
        response = uploadSslCertResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def queryAsyncJobResult(self, command, method="GET"):
        response = queryAsyncJobResultResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createLoadBalancer(self, command, method="GET"):
        response = createLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def cancelStorageMaintenance(self, command, method="GET"):
        response = cancelStorageMaintenanceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeVmwareDc(self, command, method="GET"):
        response = removeVmwareDcResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deployVirtualMachine(self, command, method="GET"):
        response = deployVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deletePod(self, command, method="GET"):
        response = deletePodResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def revokeSecurityGroupEgress(self, command, method="GET"):
        response = revokeSecurityGroupEgressResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createNetworkACLList(self, command, method="GET"):
        response = createNetworkACLListResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteCondition(self, command, method="GET"):
        response = deleteConditionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteSecondaryStagingStore(self, command, method="GET"):
        response = deleteSecondaryStagingStoreResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createPortForwardingRule(self, command, method="GET"):
        response = createPortForwardingRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetscalerLoadBalancers(self, command, method="GET"):
        response = listNetscalerLoadBalancersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVPCOffering(self, command, method="GET"):
        response = createVPCOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createEgressFirewallRule(self, command, method="GET"):
        response = createEgressFirewallRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def destroyRouter(self, command, method="GET"):
        response = destroyRouterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteAlerts(self, command, method="GET"):
        response = deleteAlertsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateLBStickinessPolicy(self, command, method="GET"):
        response = updateLBStickinessPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateSnapshotPolicy(self, command, method="GET"):
        response = updateSnapshotPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listUsageRecords(self, command, method="GET"):
        response = listUsageRecordsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def assignToGlobalLoadBalancerRule(self, command, method="GET"):
        response = assignToGlobalLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listOvsElements(self, command, method="GET"):
        response = listOvsElementsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateTrafficType(self, command, method="GET"):
        response = updateTrafficTypeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPods(self, command, method="GET"):
        response = listPodsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLdapConfigurations(self, command, method="GET"):
        response = listLdapConfigurationsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableUser(self, command, method="GET"):
        response = enableUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listOsCategories(self, command, method="GET"):
        response = listOsCategoriesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addSrxFirewall(self, command, method="GET"):
        response = addSrxFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addNiciraNvpDevice(self, command, method="GET"):
        response = addNiciraNvpDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateNetworkACLItem(self, command, method="GET"):
        response = updateNetworkACLItemResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createInstanceGroup(self, command, method="GET"):
        response = createInstanceGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addIpToNic(self, command, method="GET"):
        response = addIpToNicResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNetworkACLList(self, command, method="GET"):
        response = deleteNetworkACLListResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLunsOnFiler(self, command, method="GET"):
        response = listLunsOnFilerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateAccount(self, command, method="GET"):
        response = updateAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNetworkDevice(self, command, method="GET"):
        response = deleteNetworkDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSnapshotPolicies(self, command, method="GET"):
        response = listSnapshotPoliciesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configureInternalLoadBalancerElement(self, command, method="GET"):
        response = configureInternalLoadBalancerElementResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def modifyPool(self, command, method="GET"):
        response = modifyPoolResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def releaseHostReservation(self, command, method="GET"):
        response = releaseHostReservationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteSSHKeyPair(self, command, method="GET"):
        response = deleteSSHKeyPairResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createDomain(self, command, method="GET"):
        response = createDomainResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteSnapshotPolicies(self, command, method="GET"):
        response = deleteSnapshotPoliciesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLBHealthCheckPolicies(self, command, method="GET"):
        response = listLBHealthCheckPoliciesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listEvents(self, command, method="GET"):
        response = listEventsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def assignCertToLoadBalancer(self, command, method="GET"):
        response = assignCertToLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaEmailTemplateList(self, command, method="GET"):
        response = quotaEmailTemplateListResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addHost(self, command, method="GET"):
        response = addHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateNuageVspDevice(self, command, method="GET"):
        response = updateNuageVspDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDedicatedClusters(self, command, method="GET"):
        response = listDedicatedClustersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def destroyVolumeOnFiler(self, command, method="GET"):
        response = destroyVolumeOnFilerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def changeOutOfBandManagementPassword(self, command, method="GET"):
        response = changeOutOfBandManagementPasswordResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVpnGateway(self, command, method="GET"):
        response = deleteVpnGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def expungeVirtualMachine(self, command, method="GET"):
        response = expungeVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addNetworkDevice(self, command, method="GET"):
        response = addNetworkDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createAutoScaleVmGroup(self, command, method="GET"):
        response = createAutoScaleVmGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNetworkServiceProvider(self, command, method="GET"):
        response = deleteNetworkServiceProviderResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def rebootRouter(self, command, method="GET"):
        response = rebootRouterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listRoles(self, command, method="GET"):
        response = listRolesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createLBHealthCheckPolicy(self, command, method="GET"):
        response = createLBHealthCheckPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def archiveEvents(self, command, method="GET"):
        response = archiveEventsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listConfigurations(self, command, method="GET"):
        response = listConfigurationsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateHost(self, command, method="GET"):
        response = updateHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listProjectInvitations(self, command, method="GET"):
        response = listProjectInvitationsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listBrocadeVcsDevices(self, command, method="GET"):
        response = listBrocadeVcsDevicesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteIso(self, command, method="GET"):
        response = deleteIsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeGuestOsMapping(self, command, method="GET"):
        response = removeGuestOsMappingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVpnCustomerGateway(self, command, method="GET"):
        response = createVpnCustomerGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listTrafficTypes(self, command, method="GET"):
        response = listTrafficTypesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateResourceLimit(self, command, method="GET"):
        response = updateResourceLimitResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def lockAccount(self, command, method="GET"):
        response = lockAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateRole(self, command, method="GET"):
        response = updateRoleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteTrafficMonitor(self, command, method="GET"):
        response = deleteTrafficMonitorResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createUser(self, command, method="GET"):
        response = createUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteAutoScalePolicy(self, command, method="GET"):
        response = deleteAutoScalePolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteSrxFirewall(self, command, method="GET"):
        response = deleteSrxFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetworkIsolationMethods(self, command, method="GET"):
        response = listNetworkIsolationMethodsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateNetworkACLList(self, command, method="GET"):
        response = updateNetworkACLListResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDiskOfferings(self, command, method="GET"):
        response = listDiskOfferingsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def detachVolume(self, command, method="GET"):
        response = detachVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteUser(self, command, method="GET"):
        response = deleteUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNetworkACL(self, command, method="GET"):
        response = deleteNetworkACLResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSnapshots(self, command, method="GET"):
        response = listSnapshotsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVPC(self, command, method="GET"):
        response = deleteVPCResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteSecurityGroup(self, command, method="GET"):
        response = deleteSecurityGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listCounters(self, command, method="GET"):
        response = listCountersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteSslCert(self, command, method="GET"):
        response = deleteSslCertResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateHypervisorCapabilities(self, command, method="GET"):
        response = updateHypervisorCapabilitiesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createPhysicalNetwork(self, command, method="GET"):
        response = createPhysicalNetworkResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateLoadBalancerRule(self, command, method="GET"):
        response = updateLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createRolePermission(self, command, method="GET"):
        response = createRolePermissionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableOutOfBandManagementForHost(self, command, method="GET"):
        response = enableOutOfBandManagementForHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteTemplate(self, command, method="GET"):
        response = deleteTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listHypervisorCapabilities(self, command, method="GET"):
        response = listHypervisorCapabilitiesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listTags(self, command, method="GET"):
        response = listTagsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVpnCustomerGateway(self, command, method="GET"):
        response = deleteVpnCustomerGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteCiscoVnmcResource(self, command, method="GET"):
        response = deleteCiscoVnmcResourceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listIsoPermissions(self, command, method="GET"):
        response = listIsoPermissionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaTariffUpdate(self, command, method="GET"):
        response = quotaTariffUpdateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVirtualRouterElement(self, command, method="GET"):
        response = createVirtualRouterElementResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateAutoScalePolicy(self, command, method="GET"):
        response = updateAutoScalePolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def releaseDedicatedPod(self, command, method="GET"):
        response = releaseDedicatedPodResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVpnGateway(self, command, method="GET"):
        response = createVpnGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def dedicateZone(self, command, method="GET"):
        response = dedicateZoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteCounter(self, command, method="GET"):
        response = deleteCounterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def dedicateCluster(self, command, method="GET"):
        response = dedicateClusterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addExternalFirewall(self, command, method="GET"):
        response = addExternalFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def linkDomainToLdap(self, command, method="GET"):
        response = linkDomainToLdapResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateStorageNetworkIpRange(self, command, method="GET"):
        response = updateStorageNetworkIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAsyncJobs(self, command, method="GET"):
        response = listAsyncJobsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addBrocadeVcsDevice(self, command, method="GET"):
        response = addBrocadeVcsDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaTariffList(self, command, method="GET"):
        response = quotaTariffListResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listUsageTypes(self, command, method="GET"):
        response = listUsageTypesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSecondaryStagingStores(self, command, method="GET"):
        response = listSecondaryStagingStoresResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listF5LoadBalancerNetworks(self, command, method="GET"):
        response = listF5LoadBalancerNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVlanIpRange(self, command, method="GET"):
        response = createVlanIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addImageStore(self, command, method="GET"):
        response = addImageStoreResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def ldapCreateAccount(self, command, method="GET"):
        response = ldapCreateAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def findHostsForMigration(self, command, method="GET"):
        response = findHostsForMigrationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def dedicatePod(self, command, method="GET"):
        response = dedicatePodResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addF5LoadBalancer(self, command, method="GET"):
        response = addF5LoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteAutoScaleVmGroup(self, command, method="GET"):
        response = deleteAutoScaleVmGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateGlobalLoadBalancerRule(self, command, method="GET"):
        response = updateGlobalLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listRemoteAccessVpns(self, command, method="GET"):
        response = listRemoteAccessVpnsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def registerTemplate(self, command, method="GET"):
        response = registerTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAffinityGroupTypes(self, command, method="GET"):
        response = listAffinityGroupTypesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createServiceInstance(self, command, method="GET"):
        response = createServiceInstanceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNetworkOffering(self, command, method="GET"):
        response = deleteNetworkOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteBaremetalRct(self, command, method="GET"):
        response = deleteBaremetalRctResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def authorizeSecurityGroupEgress(self, command, method="GET"):
        response = authorizeSecurityGroupEgressResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableAutoScaleVmGroup(self, command, method="GET"):
        response = disableAutoScaleVmGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableOutOfBandManagementForCluster(self, command, method="GET"):
        response = disableOutOfBandManagementForClusterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVpnCustomerGateways(self, command, method="GET"):
        response = listVpnCustomerGatewaysResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteRolePermission(self, command, method="GET"):
        response = deleteRolePermissionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def authorizeSamlSso(self, command, method="GET"):
        response = authorizeSamlSsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createAccount(self, command, method="GET"):
        response = createAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def prepareHostForMaintenance(self, command, method="GET"):
        response = prepareHostForMaintenanceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNuageVspDevices(self, command, method="GET"):
        response = listNuageVspDevicesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listIdps(self, command, method="GET"):
        response = listIdpsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addOpenDaylightController(self, command, method="GET"):
        response = addOpenDaylightControllerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateEgressFirewallRule(self, command, method="GET"):
        response = updateEgressFirewallRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getVolumeiScsiName(self, command, method="GET"):
        response = getVolumeiScsiNameResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deletePrivateGateway(self, command, method="GET"):
        response = deletePrivateGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVolumeOnFiler(self, command, method="GET"):
        response = createVolumeOnFilerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateGuestOs(self, command, method="GET"):
        response = updateGuestOsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def stopInternalLoadBalancerVM(self, command, method="GET"):
        response = stopInternalLoadBalancerVMResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createSecondaryStagingStore(self, command, method="GET"):
        response = createSecondaryStagingStoreResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteTrafficType(self, command, method="GET"):
        response = deleteTrafficTypeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def generateUsageRecords(self, command, method="GET"):
        response = generateUsageRecordsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteLoadBalancerRule(self, command, method="GET"):
        response = deleteLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getApiLimit(self, command, method="GET"):
        response = getApiLimitResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def attachIso(self, command, method="GET"):
        response = attachIsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deletePortForwardingRule(self, command, method="GET"):
        response = deletePortForwardingRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getUser(self, command, method="GET"):
        response = getUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDomains(self, command, method="GET"):
        response = listDomainsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLoadBalancerRules(self, command, method="GET"):
        response = listLoadBalancerRulesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getVolumeSnapshotDetails(self, command, method="GET"):
        response = getVolumeSnapshotDetailsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPaloAltoFirewalls(self, command, method="GET"):
        response = listPaloAltoFirewallsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteEvents(self, command, method="GET"):
        response = deleteEventsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeCertFromLoadBalancer(self, command, method="GET"):
        response = removeCertFromLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configureSrxFirewall(self, command, method="GET"):
        response = configureSrxFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteZone(self, command, method="GET"):
        response = deleteZoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateProjectInvitation(self, command, method="GET"):
        response = updateProjectInvitationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVolume(self, command, method="GET"):
        response = deleteVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createTags(self, command, method="GET"):
        response = createTagsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableAutoScaleVmGroup(self, command, method="GET"):
        response = enableAutoScaleVmGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listOpenDaylightControllers(self, command, method="GET"):
        response = listOpenDaylightControllersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listResourceDetails(self, command, method="GET"):
        response = listResourceDetailsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPools(self, command, method="GET"):
        response = listPoolsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteLdapConfiguration(self, command, method="GET"):
        response = deleteLdapConfigurationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateCluster(self, command, method="GET"):
        response = updateClusterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeVpnUser(self, command, method="GET"):
        response = removeVpnUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSrxFirewalls(self, command, method="GET"):
        response = listSrxFirewallsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def scaleVirtualMachine(self, command, method="GET"):
        response = scaleVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPaloAltoFirewallNetworks(self, command, method="GET"):
        response = listPaloAltoFirewallNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def releasePublicIpRange(self, command, method="GET"):
        response = releasePublicIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSamlAuthorization(self, command, method="GET"):
        response = listSamlAuthorizationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listTemplates(self, command, method="GET"):
        response = listTemplatesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDedicatedGuestVlanRanges(self, command, method="GET"):
        response = listDedicatedGuestVlanRangesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVpnCustomerGateway(self, command, method="GET"):
        response = updateVpnCustomerGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateIsoPermissions(self, command, method="GET"):
        response = updateIsoPermissionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def login(self, command, method="GET"):
        response = loginResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def stopSystemVm(self, command, method="GET"):
        response = stopSystemVmResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def restartNetwork(self, command, method="GET"):
        response = restartNetworkResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def prepareTemplate(self, command, method="GET"):
        response = prepareTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeGuestOs(self, command, method="GET"):
        response = removeGuestOsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def changeServiceForRouter(self, command, method="GET"):
        response = changeServiceForRouterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def rebootVirtualMachine(self, command, method="GET"):
        response = rebootVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listGlobalLoadBalancerRules(self, command, method="GET"):
        response = listGlobalLoadBalancerRulesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeRawUsageRecords(self, command, method="GET"):
        response = removeRawUsageRecordsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def notifyBaremetalProvisionDone(self, command, method="GET"):
        response = notifyBaremetalProvisionDoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listLBStickinessPolicies(self, command, method="GET"):
        response = listLBStickinessPoliciesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateZone(self, command, method="GET"):
        response = updateZoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableCiscoNexusVSM(self, command, method="GET"):
        response = enableCiscoNexusVSMResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def ldapRemove(self, command, method="GET"):
        response = ldapRemoveResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSecurityGroups(self, command, method="GET"):
        response = listSecurityGroupsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def dedicateGuestVlanRange(self, command, method="GET"):
        response = dedicateGuestVlanRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listFirewallRules(self, command, method="GET"):
        response = listFirewallRulesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVMAffinityGroup(self, command, method="GET"):
        response = updateVMAffinityGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configurePaloAltoFirewall(self, command, method="GET"):
        response = configurePaloAltoFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaSummary(self, command, method="GET"):
        response = quotaSummaryResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVpnConnection(self, command, method="GET"):
        response = deleteVpnConnectionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAffinityGroups(self, command, method="GET"):
        response = listAffinityGroupsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateUser(self, command, method="GET"):
        response = updateUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVpnConnection(self, command, method="GET"):
        response = updateVpnConnectionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteDiskOffering(self, command, method="GET"):
        response = deleteDiskOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVpnGateway(self, command, method="GET"):
        response = updateVpnGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def startSystemVm(self, command, method="GET"):
        response = startSystemVmResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteF5LoadBalancer(self, command, method="GET"):
        response = deleteF5LoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateProject(self, command, method="GET"):
        response = updateProjectResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def archiveAlerts(self, command, method="GET"):
        response = archiveAlertsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createZone(self, command, method="GET"):
        response = createZoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listBaremetalPxeServers(self, command, method="GET"):
        response = listBaremetalPxeServersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNetwork(self, command, method="GET"):
        response = deleteNetworkResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listStaticRoutes(self, command, method="GET"):
        response = listStaticRoutesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addCiscoVnmcResource(self, command, method="GET"):
        response = addCiscoVnmcResourceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNetscalerLoadBalancer(self, command, method="GET"):
        response = deleteNetscalerLoadBalancerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def changeServiceForSystemVm(self, command, method="GET"):
        response = changeServiceForSystemVmResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNics(self, command, method="GET"):
        response = listNicsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSrxFirewallNetworks(self, command, method="GET"):
        response = listSrxFirewallNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createStoragePool(self, command, method="GET"):
        response = createStoragePoolResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeRegion(self, command, method="GET"):
        response = removeRegionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteUcsManager(self, command, method="GET"):
        response = deleteUcsManagerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listBaremetalDhcp(self, command, method="GET"):
        response = listBaremetalDhcpResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addTrafficType(self, command, method="GET"):
        response = addTrafficTypeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSwifts(self, command, method="GET"):
        response = listSwiftsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteNuageVspDevice(self, command, method="GET"):
        response = deleteNuageVspDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateTemplate(self, command, method="GET"):
        response = updateTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableUser(self, command, method="GET"):
        response = disableUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configureVirtualRouterElement(self, command, method="GET"):
        response = configureVirtualRouterElementResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createSnapshotPolicy(self, command, method="GET"):
        response = createSnapshotPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteProjectInvitation(self, command, method="GET"):
        response = deleteProjectInvitationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaEmailTemplateUpdate(self, command, method="GET"):
        response = quotaEmailTemplateUpdateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addBaremetalRct(self, command, method="GET"):
        response = addBaremetalRctResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateInstanceGroup(self, command, method="GET"):
        response = updateInstanceGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def migrateSystemVm(self, command, method="GET"):
        response = migrateSystemVmResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createServiceOffering(self, command, method="GET"):
        response = createServiceOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeNicFromVirtualMachine(self, command, method="GET"):
        response = removeNicFromVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteCiscoAsa1000vResource(self, command, method="GET"):
        response = deleteCiscoAsa1000vResourceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def revokeSecurityGroupIngress(self, command, method="GET"):
        response = revokeSecurityGroupIngressResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateDefaultNicForVirtualMachine(self, command, method="GET"):
        response = updateDefaultNicForVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableStaticNat(self, command, method="GET"):
        response = disableStaticNatResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listExternalFirewalls(self, command, method="GET"):
        response = listExternalFirewallsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createNetworkACL(self, command, method="GET"):
        response = createNetworkACLResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createPod(self, command, method="GET"):
        response = createPodResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVPC(self, command, method="GET"):
        response = createVPCResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listOsTypes(self, command, method="GET"):
        response = listOsTypesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addBaremetalPxeKickStartServer(self, command, method="GET"):
        response = addBaremetalPxeKickStartServerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSslCerts(self, command, method="GET"):
        response = listSslCertsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaBalance(self, command, method="GET"):
        response = quotaBalanceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def registerIso(self, command, method="GET"):
        response = registerIsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addResourceDetail(self, command, method="GET"):
        response = addResourceDetailResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disassociateIpAddress(self, command, method="GET"):
        response = disassociateIpAddressResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listZones(self, command, method="GET"):
        response = listZonesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def issueOutOfBandManagementPowerAction(self, command, method="GET"):
        response = issueOutOfBandManagementPowerActionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listExternalLoadBalancers(self, command, method="GET"):
        response = listExternalLoadBalancersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createVolume(self, command, method="GET"):
        response = createVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def resetPasswordForVirtualMachine(self, command, method="GET"):
        response = resetPasswordForVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def assignToLoadBalancerRule(self, command, method="GET"):
        response = assignToLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def startRouter(self, command, method="GET"):
        response = startRouterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listUcsBlades(self, command, method="GET"):
        response = listUcsBladesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateGuestOsMapping(self, command, method="GET"):
        response = updateGuestOsMappingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def extractIso(self, command, method="GET"):
        response = extractIsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeResourceDetail(self, command, method="GET"):
        response = removeResourceDetailResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def changeServiceForVirtualMachine(self, command, method="GET"):
        response = changeServiceForVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteRemoteAccessVpn(self, command, method="GET"):
        response = deleteRemoteAccessVpnResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addVmwareDc(self, command, method="GET"):
        response = addVmwareDcResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteImageStore(self, command, method="GET"):
        response = deleteImageStoreResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVlanIpRange(self, command, method="GET"):
        response = deleteVlanIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listStoragePools(self, command, method="GET"):
        response = listStoragePoolsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def resetVpnConnection(self, command, method="GET"):
        response = resetVpnConnectionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listStorageTags(self, command, method="GET"):
        response = listStorageTagsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createRemoteAccessVpn(self, command, method="GET"):
        response = createRemoteAccessVpnResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def extractTemplate(self, command, method="GET"):
        response = extractTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def startVirtualMachine(self, command, method="GET"):
        response = startVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSystemVms(self, command, method="GET"):
        response = listSystemVmsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def detachIso(self, command, method="GET"):
        response = detachIsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteServiceOffering(self, command, method="GET"):
        response = deleteServiceOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteAccount(self, command, method="GET"):
        response = deleteAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetworkDevice(self, command, method="GET"):
        response = listNetworkDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteBigSwitchBcfDevice(self, command, method="GET"):
        response = deleteBigSwitchBcfDeviceResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def associateIpAddress(self, command, method="GET"):
        response = associateIpAddressResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableAccount(self, command, method="GET"):
        response = disableAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def migrateVirtualMachine(self, command, method="GET"):
        response = migrateVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getUploadParamsForTemplate(self, command, method="GET"):
        response = getUploadParamsForTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateDomain(self, command, method="GET"):
        response = updateDomainResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVMSnapshot(self, command, method="GET"):
        response = listVMSnapshotResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDedicatedZones(self, command, method="GET"):
        response = listDedicatedZonesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def removeFromLoadBalancerRule(self, command, method="GET"):
        response = removeFromLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addImageStoreS3(self, command, method="GET"):
        response = addImageStoreS3Response()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def resetApiLimit(self, command, method="GET"):
        response = resetApiLimitResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def registerUserKeys(self, command, method="GET"):
        response = registerUserKeysResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableOutOfBandManagementForHost(self, command, method="GET"):
        response = disableOutOfBandManagementForHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addVpnUser(self, command, method="GET"):
        response = addVpnUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVPCs(self, command, method="GET"):
        response = listVPCsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def assignVirtualMachine(self, command, method="GET"):
        response = assignVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateLBHealthCheckPolicy(self, command, method="GET"):
        response = updateLBHealthCheckPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateFirewallRule(self, command, method="GET"):
        response = updateFirewallRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listConditions(self, command, method="GET"):
        response = listConditionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createPrivateGateway(self, command, method="GET"):
        response = createPrivateGatewayResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteLBStickinessPolicy(self, command, method="GET"):
        response = deleteLBStickinessPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateVirtualMachine(self, command, method="GET"):
        response = updateVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getSPMetadata(self, command, method="GET"):
        response = getSPMetadataResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getSolidFireVolumeSize(self, command, method="GET"):
        response = getSolidFireVolumeSizeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listResourceLimits(self, command, method="GET"):
        response = listResourceLimitsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listServiceOfferings(self, command, method="GET"):
        response = listServiceOfferingsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addUcsManager(self, command, method="GET"):
        response = addUcsManagerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def disableCiscoNexusVSM(self, command, method="GET"):
        response = disableCiscoNexusVSMResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVMSnapshot(self, command, method="GET"):
        response = deleteVMSnapshotResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteAutoScaleVmProfile(self, command, method="GET"):
        response = deleteAutoScaleVmProfileResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteStoragePool(self, command, method="GET"):
        response = deleteStoragePoolResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def samlSso(self, command, method="GET"):
        response = samlSsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteRole(self, command, method="GET"):
        response = deleteRoleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteSnapshot(self, command, method="GET"):
        response = deleteSnapshotResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createProject(self, command, method="GET"):
        response = createProjectResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createLoadBalancerRule(self, command, method="GET"):
        response = createLoadBalancerRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createAutoScalePolicy(self, command, method="GET"):
        response = createAutoScalePolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def restoreVirtualMachine(self, command, method="GET"):
        response = restoreVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def logout(self, command, method="GET"):
        response = logoutResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listEventTypes(self, command, method="GET"):
        response = listEventTypesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteAffinityGroup(self, command, method="GET"):
        response = deleteAffinityGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createNetworkOffering(self, command, method="GET"):
        response = createNetworkOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def copyIso(self, command, method="GET"):
        response = copyIsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def dedicatePublicIpRange(self, command, method="GET"):
        response = dedicatePublicIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addGuestOsMapping(self, command, method="GET"):
        response = addGuestOsMappingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listDomainChildren(self, command, method="GET"):
        response = listDomainChildrenResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def uploadVolume(self, command, method="GET"):
        response = uploadVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAutoScaleVmProfiles(self, command, method="GET"):
        response = listAutoScaleVmProfilesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createLBStickinessPolicy(self, command, method="GET"):
        response = createLBStickinessPolicyResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def migrateVirtualMachineWithVolume(self, command, method="GET"):
        response = migrateVirtualMachineWithVolumeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def stopVirtualMachine(self, command, method="GET"):
        response = stopVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createCounter(self, command, method="GET"):
        response = createCounterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listAccounts(self, command, method="GET"):
        response = listAccountsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createSnapshot(self, command, method="GET"):
        response = createSnapshotResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateIso(self, command, method="GET"):
        response = updateIsoResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPortableIpRanges(self, command, method="GET"):
        response = listPortableIpRangesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def configureOvsElement(self, command, method="GET"):
        response = configureOvsElementResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listIpForwardingRules(self, command, method="GET"):
        response = listIpForwardingRulesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateNetwork(self, command, method="GET"):
        response = updateNetworkResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def destroyVirtualMachine(self, command, method="GET"):
        response = destroyVirtualMachineResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def enableOutOfBandManagementForZone(self, command, method="GET"):
        response = enableOutOfBandManagementForZoneResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def dissociateLun(self, command, method="GET"):
        response = dissociateLunResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def dedicateHost(self, command, method="GET"):
        response = dedicateHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listHostTags(self, command, method="GET"):
        response = listHostTagsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addRegion(self, command, method="GET"):
        response = addRegionResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createDiskOffering(self, command, method="GET"):
        response = createDiskOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def getCloudIdentifier(self, command, method="GET"):
        response = getCloudIdentifierResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listNetscalerLoadBalancerNetworks(self, command, method="GET"):
        response = listNetscalerLoadBalancerNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteExternalFirewall(self, command, method="GET"):
        response = deleteExternalFirewallResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def createFirewallRule(self, command, method="GET"):
        response = createFirewallRuleResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listInternalLoadBalancerVMs(self, command, method="GET"):
        response = listInternalLoadBalancerVMsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateResourceCount(self, command, method="GET"):
        response = updateResourceCountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addNetworkServiceProvider(self, command, method="GET"):
        response = addNetworkServiceProviderResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def rebootSystemVm(self, command, method="GET"):
        response = rebootSystemVmResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def revertToVMSnapshot(self, command, method="GET"):
        response = revertToVMSnapshotResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def markDefaultZoneForAccount(self, command, method="GET"):
        response = markDefaultZoneForAccountResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def lockUser(self, command, method="GET"):
        response = lockUserResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaStatement(self, command, method="GET"):
        response = quotaStatementResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addLdapConfiguration(self, command, method="GET"):
        response = addLdapConfigurationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVirtualMachines(self, command, method="GET"):
        response = listVirtualMachinesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def restartVPC(self, command, method="GET"):
        response = restartVPCResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def replaceNetworkACLList(self, command, method="GET"):
        response = replaceNetworkACLListResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def generateAlert(self, command, method="GET"):
        response = generateAlertResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def scaleSystemVm(self, command, method="GET"):
        response = scaleSystemVmResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listEgressFirewallRules(self, command, method="GET"):
        response = listEgressFirewallRulesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateAutoScaleVmGroup(self, command, method="GET"):
        response = updateAutoScaleVmGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listHosts(self, command, method="GET"):
        response = listHostsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateTemplatePermissions(self, command, method="GET"):
        response = updateTemplatePermissionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVlanIpRanges(self, command, method="GET"):
        response = listVlanIpRangesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listBaremetalRct(self, command, method="GET"):
        response = listBaremetalRctResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listPhysicalNetworks(self, command, method="GET"):
        response = listPhysicalNetworksResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listStorageNetworkIpRange(self, command, method="GET"):
        response = listStorageNetworkIpRangeResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVpnConnections(self, command, method="GET"):
        response = listVpnConnectionsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteHost(self, command, method="GET"):
        response = deleteHostResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVPCOfferings(self, command, method="GET"):
        response = listVPCOfferingsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateNetworkOffering(self, command, method="GET"):
        response = updateNetworkOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deletePhysicalNetwork(self, command, method="GET"):
        response = deletePhysicalNetworkResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteInstanceGroup(self, command, method="GET"):
        response = deleteInstanceGroupResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addBaremetalDhcp(self, command, method="GET"):
        response = addBaremetalDhcpResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteVPCOffering(self, command, method="GET"):
        response = deleteVPCOfferingResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def quotaUpdate(self, command, method="GET"):
        response = quotaUpdateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def associateLun(self, command, method="GET"):
        response = associateLunResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVpnUsers(self, command, method="GET"):
        response = listVpnUsersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updatePod(self, command, method="GET"):
        response = updatePodResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deletePool(self, command, method="GET"):
        response = deletePoolResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteOpenDaylightController(self, command, method="GET"):
        response = deleteOpenDaylightControllerResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listVmwareDcs(self, command, method="GET"):
        response = listVmwareDcsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def deleteCluster(self, command, method="GET"):
        response = deleteClusterResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def updateNetworkServiceProvider(self, command, method="GET"):
        response = updateNetworkServiceProviderResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def findStoragePoolsForMigration(self, command, method="GET"):
        response = findStoragePoolsForMigrationResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listUsers(self, command, method="GET"):
        response = listUsersResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def upgradeRouterTemplate(self, command, method="GET"):
        response = upgradeRouterTemplateResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listSupportedNetworkServices(self, command, method="GET"):
        response = listSupportedNetworkServicesResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addStratosphereSsp(self, command, method="GET"):
        response = addStratosphereSspResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def addGuestOs(self, command, method="GET"):
        response = addGuestOsResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def listIsos(self, command, method="GET"):
        response = listIsosResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

    def revertSnapshot(self, command, method="GET"):
        response = revertSnapshotResponse()
        response = self.connection.marvinRequest(command, response_type=response, method=method)
        return response

