# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


"""Create a quota statement"""
from baseCmd import *
from baseResponse import *
class quotaStatementCmd (baseCmd):
    typeInfo = {}
    def __init__(self):
        self.isAsync = "false"
        """Optional, Account Id for which statement needs to be generated"""
        """Required"""
        self.account = None
        self.typeInfo['account'] = 'string'
        """Optional, If domain Id is given and the caller is domain admin then the statement is generated for domain."""
        """Required"""
        self.domainid = None
        self.typeInfo['domainid'] = 'uuid'
        """End date range for quota query. Use yyyy-MM-dd as the date format, e.g. startDate=2009-06-03."""
        """Required"""
        self.enddate = None
        self.typeInfo['enddate'] = 'date'
        """Start date range quota query. Use yyyy-MM-dd as the date format, e.g. startDate=2009-06-01."""
        """Required"""
        self.startdate = None
        self.typeInfo['startdate'] = 'date'
        """List usage records for the specified account"""
        self.accountid = None
        self.typeInfo['accountid'] = 'uuid'
        """List quota usage records for the specified usage type"""
        self.type = None
        self.typeInfo['type'] = 'integer'
        self.required = ["account","domainid","enddate","startdate",]

class quotaStatementResponse (baseResponse):
    typeInfo = {}
    def __init__(self):
        """account name"""
        self.account = None
        self.typeInfo['account'] = 'string'
        """account id"""
        self.accountid = None
        self.typeInfo['accountid'] = 'long'
        """domain id"""
        self.domain = None
        self.typeInfo['domain'] = 'long'
        """usage type name"""
        self.name = None
        self.typeInfo['name'] = 'string'
        """quota consumed"""
        self.quota = None
        self.typeInfo['quota'] = 'bigdecimal'
        """usage type"""
        self.type = None
        self.typeInfo['type'] = 'int'
        """usage unit"""
        self.unit = None
        self.typeInfo['unit'] = 'string'

