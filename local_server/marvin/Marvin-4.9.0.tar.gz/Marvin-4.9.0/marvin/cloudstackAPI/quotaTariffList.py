# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


"""Lists all quota tariff plans"""
from baseCmd import *
from baseResponse import *
class quotaTariffListCmd (baseCmd):
    typeInfo = {}
    def __init__(self):
        self.isAsync = "false"
        """List by keyword"""
        self.keyword = None
        self.typeInfo['keyword'] = 'string'
        """"""
        self.page = None
        self.typeInfo['page'] = 'integer'
        """"""
        self.pagesize = None
        self.typeInfo['pagesize'] = 'integer'
        """The effective start date on/after which the quota tariff is effective and older tariffs are no longer used for the usage type. Use yyyy-MM-dd as the date format, e.g. startDate=2009-06-03."""
        self.startdate = None
        self.typeInfo['startdate'] = 'date'
        """Usage type of the resource"""
        self.usagetype = None
        self.typeInfo['usagetype'] = 'integer'
        self.required = []

class quotaTariffListResponse (baseResponse):
    typeInfo = {}
    def __init__(self):
        """currency"""
        self.currency = None
        self.typeInfo['currency'] = 'string'
        """description"""
        self.description = None
        self.typeInfo['description'] = 'string'
        """the date on/after which this quota value will be effective"""
        self.effectiveDate = None
        self.typeInfo['effectiveDate'] = 'date'
        """tariffValue"""
        self.tariffValue = None
        self.typeInfo['tariffValue'] = 'bigdecimal'
        """usageDiscriminator"""
        self.usageDiscriminator = None
        self.typeInfo['usageDiscriminator'] = 'string'
        """usageName"""
        self.usageName = None
        self.typeInfo['usageName'] = 'string'
        """usageType"""
        self.usageType = None
        self.typeInfo['usageType'] = 'int'
        """usageUnit"""
        self.usageUnit = None
        self.typeInfo['usageUnit'] = 'string'

