# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


"""Lists balance and quota usage for all accounts"""
from baseCmd import *
from baseResponse import *
class quotaSummaryCmd (baseCmd):
    typeInfo = {}
    def __init__(self):
        self.isAsync = "false"
        """Optional, Account Id for which statement needs to be generated"""
        self.account = None
        self.typeInfo['account'] = 'string'
        """Optional, If domain Id is given and the caller is domain admin then the statement is generated for domain."""
        self.domainid = None
        self.typeInfo['domainid'] = 'uuid'
        """List by keyword"""
        self.keyword = None
        self.typeInfo['keyword'] = 'string'
        """Optional, to list all accounts irrespective of the quota activity"""
        self.listall = None
        self.typeInfo['listall'] = 'boolean'
        """"""
        self.page = None
        self.typeInfo['page'] = 'integer'
        """"""
        self.pagesize = None
        self.typeInfo['pagesize'] = 'integer'
        self.required = []

class quotaSummaryResponse (baseResponse):
    typeInfo = {}
    def __init__(self):
        """account name"""
        self.account = None
        self.typeInfo['account'] = 'string'
        """account id"""
        self.accountid = None
        self.typeInfo['accountid'] = 'long'
        """account balance"""
        self.balance = None
        self.typeInfo['balance'] = 'bigdecimal'
        """currency"""
        self.currency = None
        self.typeInfo['currency'] = 'string'
        """domain name"""
        self.domain = None
        self.typeInfo['domain'] = 'string'
        """domain id"""
        self.domainid = None
        self.typeInfo['domainid'] = 'long'
        """end date"""
        self.enddate = None
        self.typeInfo['enddate'] = 'date'
        """quota usage of this period"""
        self.quota = None
        self.typeInfo['quota'] = 'bigdecimal'
        """start date"""
        self.startdate = None
        self.typeInfo['startdate'] = 'date'
        """account state"""
        self.state = None
        self.typeInfo['state'] = 'state'

