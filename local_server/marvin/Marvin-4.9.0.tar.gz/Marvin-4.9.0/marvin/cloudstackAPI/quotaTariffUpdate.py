# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


"""Update the tariff plan for a resource"""
from baseCmd import *
from baseResponse import *
class quotaTariffUpdateCmd (baseCmd):
    typeInfo = {}
    def __init__(self):
        self.isAsync = "false"
        """The effective start date on/after which the quota tariff is effective and older tariffs are no longer used for the usage type. Use yyyy-MM-dd as the date format, e.g. startDate=2009-06-03."""
        """Required"""
        self.startdate = None
        self.typeInfo['startdate'] = 'date'
        """Integer value for the usage type of the resource"""
        """Required"""
        self.usagetype = None
        self.typeInfo['usagetype'] = 'integer'
        """The quota tariff value of the resource as per the default unit"""
        """Required"""
        self.value = None
        self.typeInfo['value'] = 'double'
        self.required = ["startdate","usagetype","value",]

class quotaTariffUpdateResponse (baseResponse):
    typeInfo = {}
    def __init__(self):
        """currency"""
        self.currency = None
        self.typeInfo['currency'] = 'string'
        """description"""
        self.description = None
        self.typeInfo['description'] = 'string'
        """the date on/after which this quota value will be effective"""
        self.effectiveDate = None
        self.typeInfo['effectiveDate'] = 'date'
        """tariffValue"""
        self.tariffValue = None
        self.typeInfo['tariffValue'] = 'bigdecimal'
        """usageDiscriminator"""
        self.usageDiscriminator = None
        self.typeInfo['usageDiscriminator'] = 'string'
        """usageName"""
        self.usageName = None
        self.typeInfo['usageName'] = 'string'
        """usageType"""
        self.usageType = None
        self.typeInfo['usageType'] = 'int'
        """usageUnit"""
        self.usageUnit = None
        self.typeInfo['usageUnit'] = 'string'

