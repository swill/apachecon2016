# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.


"""link an existing cloudstack domain to group or OU in ldap"""
from baseCmd import *
from baseResponse import *
class linkDomainToLdapCmd (baseCmd):
    typeInfo = {}
    def __init__(self):
        self.isAsync = "false"
        """Type of the account to auto import. Specify 0 for user and 2 for domain admin"""
        """Required"""
        self.accounttype = None
        self.typeInfo['accounttype'] = 'short'
        """The id of the domain which has to be linked to LDAP."""
        """Required"""
        self.domainid = None
        self.typeInfo['domainid'] = 'uuid'
        """name of the group or OU in LDAP"""
        """Required"""
        self.name = None
        self.typeInfo['name'] = 'string'
        """type of the ldap name. GROUP or OU"""
        """Required"""
        self.type = None
        self.typeInfo['type'] = 'string'
        """domain admin username in LDAP"""
        self.admin = None
        self.typeInfo['admin'] = 'string'
        self.required = ["accounttype","domainid","name","type",]

class linkDomainToLdapResponse (baseResponse):
    typeInfo = {}
    def __init__(self):
        """Domain Admin accountId that is created"""
        self.accountid = None
        self.typeInfo['accountid'] = 'string'
        """Type of the account to auto import"""
        self.accounttype = None
        self.typeInfo['accounttype'] = 'short'
        """id of the Domain which is linked to LDAP"""
        self.domainid = None
        self.typeInfo['domainid'] = 'long'
        """name of the group or OU in LDAP which is linked to the domain"""
        self.name = None
        self.typeInfo['name'] = 'string'
        """type of the name in LDAP which is linke to the domain"""
        self.type = None
        self.typeInfo['type'] = 'string'

